#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/ui/GeodeUI.hpp>
#include <Geode/utils/cocos.hpp>
#include <Geode/utils/web.hpp>
#include <algorithm>
#include <cmath>
#include <deque>
#include <functional>
#include <string>
#include <vector>

using namespace geode::prelude;

// ======================================================================
//  GEOMETRY / PLANNING  (pure logic)
// ======================================================================
// ---- GEOMETRY BEGIN
struct Obs {
    int kind = 0;             // 0 rect, 1 triangle (slope), 2 circle
    CCRect rect;              // bounding box
    CCPoint tri[3];
    CCPoint center;
    float radius = 0.f;
};

using ObsList = std::vector<Obs const*>;

static float sgn(CCPoint a, CCPoint b, CCPoint c) {
    return (a.x - c.x) * (b.y - c.y) - (b.x - c.x) * (a.y - c.y);
}

static bool inTri(CCPoint p, CCPoint const* t) {
    float d1 = sgn(p, t[0], t[1]);
    float d2 = sgn(p, t[1], t[2]);
    float d3 = sgn(p, t[2], t[0]);
    bool neg = d1 < 0 || d2 < 0 || d3 < 0;
    bool pos = d1 > 0 || d2 > 0 || d3 > 0;
    return !(neg && pos);
}

static bool rectTri(CCRect const& r, CCPoint const* t) {
    float xs[3] = {r.getMinX(), r.getMidX(), r.getMaxX()};
    float ys[3] = {r.getMinY(), r.getMidY(), r.getMaxY()};
    for (float x : xs)
        for (float y : ys)
            if (inTri(CCPoint(x, y), t)) return true;
    for (int i = 0; i < 3; i++) {
        auto a = t[i];
        auto b = t[(i + 1) % 3];
        if (r.containsPoint(a)) return true;
        if (r.containsPoint(CCPoint((a.x + b.x) / 2.f, (a.y + b.y) / 2.f))) return true;
    }
    return false;
}

static bool circleRect(CCPoint c, float rad, CCRect const& r) {
    float cx = std::clamp(c.x, r.getMinX(), r.getMaxX());
    float cy = std::clamp(c.y, r.getMinY(), r.getMaxY());
    float dx = c.x - cx;
    float dy = c.y - cy;
    return dx * dx + dy * dy <= rad * rad;
}

static bool hitsList(ObsList const& list, CCRect const& s) {
    for (auto o : list) {
        if (o->rect.getMaxX() < s.getMinX() || o->rect.getMinX() > s.getMaxX() ||
            o->rect.getMaxY() < s.getMinY() || o->rect.getMinY() > s.getMaxY()) continue;
        if (o->kind == 0) return true;
        if (o->kind == 1 && rectTri(s, o->tri)) return true;
        if (o->kind == 2 && circleRect(o->center, o->radius, s)) return true;
    }
    return false;
}

static void filterObs(std::vector<Obs> const& cache, ObsList& out,
                      float minX, float maxX, float minY, float maxY) {
    out.clear();
    for (auto const& o : cache) {
        if (o.rect.getMaxX() < minX || o.rect.getMinX() > maxX ||
            o.rect.getMaxY() < minY || o.rect.getMinY() > maxY) continue;
        out.push_back(&o);
    }
}

// One wave that the bot is steering.
struct Agent {
    int player = 0;
    float cx0 = 0.f, cy0 = 0.f;   // sensor center now
    float dx = 0.f, d = 0.f;      // x step and |y| step per tick
    float hsx = 0.f, hsy = 0.f;   // sensor half size
    float sign = 1.f;             // +1 normal gravity, -1 upside down (holding moves it down)
    ObsList obs;                  // obstacles near this agent
};

// After i ticks with u of them "held", agent a is at
//   x = cx0 + i*dx,   y = cy0 + sign*(2u - i)*d
// All agents of a channel share the same hold sequence.
// Returns true = hold the button, false = release.
static bool planHold(std::vector<Agent> const& ag, int H, bool prevHold, float threshold) {
    int W = H + 2;
    static std::vector<double> cnt;
    static std::vector<int> dep;
    cnt.assign((H + 2) * W, 0.0);
    dep.assign((H + 2) * W, 0);

    for (int i = H; i >= 1; i--) {
        for (int u = 0; u <= i; u++) {
            bool bad = false;
            for (auto const& a : ag) {
                CCRect s(a.cx0 + i * a.dx - a.hsx,
                         a.cy0 + a.sign * static_cast<float>(2 * u - i) * a.d - a.hsy,
                         2.f * a.hsx, 2.f * a.hsy);
                if (hitsList(a.obs, s)) { bad = true; break; }
            }
            if (bad) continue;
            int idx = i * W + u;
            if (i == H) {
                cnt[idx] = 1.0;
                dep[idx] = 1;
            } else {
                cnt[idx] = cnt[(i + 1) * W + u + 1] + cnt[(i + 1) * W + u];
                dep[idx] = 1 + std::max(dep[(i + 1) * W + u + 1], dep[(i + 1) * W + u]);
            }
        }
    }

    double ch = cnt[W + 1], cr = cnt[W];
    int dh = dep[W + 1], dr = dep[W];

    if (ch > 0.0 || cr > 0.0) {
        double cur = prevHold ? ch : cr;
        double oth = prevHold ? cr : ch;
        if (cur <= 0.0) return !prevHold;               // blocked: must switch
        double share = oth / (cur + oth);
        double need = 0.5 + 0.5 * static_cast<double>(threshold);
        return share > need ? !prevHold : prevHold;     // hysteresis
    }
    if (dh != dr) return dh > dr;                       // no safe path: survive longest
    return prevHold;
}

struct Vote {
    int v = 0;            // +1 hold, -1 release, 0 no opinion
    bool urgent = false;  // the sensor really overlaps something
};

// Bounce: slope above -> go down, slope below -> go up.
// The next real step (forward and up / down) is checked.
static Vote bounceVote(Agent const& a, float probe, bool curUp) {
    CCRect here(a.cx0 - a.hsx, a.cy0 - a.hsy, 2.f * a.hsx, 2.f * a.hsy);
    CCRect up(a.cx0 + a.dx - a.hsx, a.cy0 - a.hsy + probe, 2.f * a.hsx, 2.f * a.hsy);
    CCRect dn(a.cx0 + a.dx - a.hsx, a.cy0 - a.hsy - probe, 2.f * a.hsx, 2.f * a.hsy);
    bool upHit = hitsList(a.obs, up);
    bool dnHit = hitsList(a.obs, dn);
    bool hereHit = hitsList(a.obs, here);

    Vote r;
    r.urgent = hereHit;
    bool have = false;
    bool wantUp = curUp;
    if (upHit && !dnHit) { wantUp = false; have = true; }
    else if (dnHit && !upHit) { wantUp = true; have = true; }
    else if (upHit && dnHit && hereHit) { wantUp = !curUp; have = true; } // squeezed

    if (have) r.v = (wantUp == (a.sign > 0.f)) ? 1 : -1;
    return r;
}

// ---------------------------------------------------------------------
//  Click window (pure logic): how many frames earlier / later could a
//  click have been pressed and still survive?
// ---------------------------------------------------------------------
struct CwTick {
    float x = 0.f, y = 0.f;      // player position before this tick moved it
    float dx = 0.f, d = 0.f;     // x step and |y| step
    float sign = 1.f;            // +1 normal, -1 upside down
    bool hold = false;           // button state used for this tick
    float hsx = 0.f, hsy = 0.f;  // sensor half size
    float ox = 0.f, oy = 0.f;    // sensor center offset
};

struct CwCtx {
    std::deque<CwTick> const* h = nullptr;
    long baseTick = 0, tn = 0, ts = 0, te = 0, e1 = 0;
    long Lmax = 0, Rmax = 0;
    float hsx = 0.f, hsy = 0.f, ox = 0.f, oy = 0.f;
    ObsList list;

    CwTick const& at(long t) const {
        long i = std::min(t, tn) - baseTick;
        return (*h)[static_cast<size_t>(i)];
    }

    // button state at tick t when the click at e1 is moved by dlt ticks
    bool holdAt(long t, int dlt) const {
        bool a = at(e1 - 1).hold;
        bool b = at(e1).hold;
        if (dlt > 0 && t >= e1 && t < e1 + dlt) return a;
        if (dlt < 0 && t >= e1 + dlt && t < e1) return b;
        return at(t).hold;
    }

    // returns the tick where the wave dies, or -1 if it survives
    long simulate(int dlt, std::vector<CCPoint>* pts) const {
        float x = at(ts).x, y = at(ts).y;
        for (long t = ts; t <= te + 1; t++) {
            CCRect s(x + ox - hsx, y + oy - hsy, 2.f * hsx, 2.f * hsy);
            if (pts) pts->push_back(CCPoint(x + ox, y + oy));
            if (hitsList(list, s)) return t;
            auto const& T = at(t);
            float dirY = (holdAt(t, dlt) ? 1.f : -1.f) * T.sign;
            x += T.dx;
            y += dirY * T.d;
        }
        return -1;
    }
};

// e0 = previous click tick (or -1), e1 = the click to measure, e2 = the next click (= latest tick)
static bool cwSetup(CwCtx& c, std::deque<CwTick> const& h, long baseTick, long e0, long e1, long e2,
                    int range, int E, std::vector<Obs> const& cache) {
    long tn = baseTick + static_cast<long>(h.size()) - 1;
    if (e1 <= baseTick || e2 > tn || e2 <= e1) return false;

    long Lmax = e0 >= 0 ? (e1 - e0 - 1) : (e1 - baseTick);
    Lmax = std::min<long>({Lmax, static_cast<long>(range), e1 - baseTick});
    long Rmax = std::min<long>(static_cast<long>(range), e2 - e1 - 1);
    if (Lmax < 0) Lmax = 0;
    if (Rmax < 0) Rmax = 0;

    c.h = &h;
    c.baseTick = baseTick;
    c.tn = tn;
    c.e1 = e1;
    c.Lmax = Lmax;
    c.Rmax = Rmax;
    c.ts = e1 - Lmax;
    c.te = tn + E;

    auto const& B = c.at(e1);
    c.hsx = B.hsx;
    c.hsy = B.hsy;
    c.ox = B.ox;
    c.oy = B.oy;

    float maxd = 0.f;
    for (long t = c.ts; t <= tn; t++) maxd = std::max(maxd, c.at(t).d);
    float N = static_cast<float>(c.te - c.ts + 2);
    float yc = c.at(c.ts).y + c.oy;
    float x0 = c.at(c.ts).x + c.ox - c.hsx - 1.f;
    float x1 = c.at(tn).x + c.ox + c.hsx + static_cast<float>(E + 1) * c.at(tn).dx + 1.f;
    filterObs(cache, c.list, x0, x1, yc - N * maxd - c.hsy - 1.f, yc + N * maxd + c.hsy + 1.f);
    return true;
}

struct CwResult {
    std::vector<char> safe;  // index = shift + Lmax
    int a = 0, b = 0;        // frames earlier / later that still survive
    bool zeroSafe = false;   // the real click survives in the model
};

static CwResult cwWindow(CwCtx const& c) {
    CwResult r;
    r.safe.assign(static_cast<size_t>(c.Lmax + c.Rmax + 1), 0);
    for (long dlt = -c.Lmax; dlt <= c.Rmax; dlt++) {
        r.safe[static_cast<size_t>(dlt + c.Lmax)] = c.simulate(static_cast<int>(dlt), nullptr) < 0 ? 1 : 0;
    }
    r.zeroSafe = r.safe[static_cast<size_t>(c.Lmax)] != 0;
    while (r.a < c.Lmax && r.safe[static_cast<size_t>(c.Lmax - r.a - 1)]) r.a++;
    while (r.b < c.Rmax && r.safe[static_cast<size_t>(c.Lmax + r.b + 1)]) r.b++;
    return r;
}
// ---- GEOMETRY END

// ======================================================================
//  STATE
// ======================================================================
namespace {
    struct Motion {
        bool haveLast = false;
        float lastX = 0.f, lastY = 0.f;
        float dx = 0.f;   // x movement per tick
        float k = 1.f;    // |dy| / dx of the wave
    };
    struct SpamState {
        bool down = false;
        float accum = 0.f;
        int frames = 0;
    };

    // channel 0 = player 1's input (or the shared input in a normal dual level)
    // channel 1 = player 2's input (2-player levels only)
    Motion s_motion[2];
    SpamState s_spam[2];
    bool s_userHold[2] = {false, false};  // the real finger
    bool s_hold[2] = {false, false};      // the bot's simulated button
    bool s_ctl[2] = {false, false};       // the bot steers this channel
    bool s_injecting = false;
    bool s_twoP = false;

    std::vector<Obs> s_cache;
    float s_cacheX = -1e9f;

    // ---- click window state
    struct CwPlayer {
        std::deque<CwTick> h;
        long baseTick = 0;
        long ev[2] = {-1, -1};  // last two click ticks (older, newer)
        int evCount = 0;
    };
    struct CwDot { CCPoint p; ccColor4F c; };
    struct CwSeg { CCPoint a, b; ccColor4F c; };
    struct CwMeas {
        float expire = 0.f;
        std::vector<CwDot> dots;
        std::vector<CwSeg> segs;
    };
    struct CwStats {
        int clicks = 0;
        double sum = 0.0;
        int minW = 0;
        int fp = 0;
    };

    CwPlayer s_cw[2];
    std::deque<CwMeas> s_meas;
    CwStats s_cwStats;
    float s_cwTime = 0.f;
    float s_cwDt = 1.f / 240.f;
    float s_cwHudUntil = -1.f;
    std::string s_cwHud;
    ccColor3B s_cwHudColor = {255, 255, 255};

    void resetState() {
        for (int i = 0; i < 2; i++) {
            s_motion[i] = Motion();
            s_spam[i] = SpamState();
            s_userHold[i] = false;
            s_hold[i] = false;
            s_ctl[i] = false;
        }
        s_injecting = false;
        s_twoP = false;
        s_cache.clear();
        s_cacheX = -1e9f;
        s_cw[0] = CwPlayer();
        s_cw[1] = CwPlayer();
        s_meas.clear();
        s_cwTime = 0.f;
        s_cwHudUntil = -1.f;
        s_cwHud.clear();
    }
}

// ======================================================================
//  LEVEL CACHE
// ======================================================================
static void rebuildCache(GJBaseGameLayer* L, float px) {
    s_cache.clear();
    s_cacheX = px;
    if (!L->m_objects) return;

    for (auto obj : CCArrayExt<GameObject*>(L->m_objects)) {
        if (!obj) continue;
        auto type = obj->m_objectType;
        if (type != GameObjectType::Solid && type != GameObjectType::Hazard &&
            type != GameObjectType::Slope) continue;

        float ox = obj->getPositionX();
        if (ox < px - 120.f || ox > px + 700.f) continue;

        Obs o;
        o.rect = obj->getObjectRect();
        if (o.rect.size.width <= 0.f || o.rect.size.height <= 0.f) continue;

        if (type == GameObjectType::Slope) {
            o.kind = 1;
            CCPoint v[3] = {CCPoint(0, 0), CCPoint(1, 0), CCPoint(1, 1)};
            for (auto& p : v) {
                if (obj->m_isFlipX) p.x = 1.f - p.x;
                if (obj->m_isFlipY) p.y = 1.f - p.y;
            }
            int turns = ((static_cast<int>(std::lround(obj->getRotation() / 90.f)) % 4) + 4) % 4;
            for (int t = 0; t < turns; t++) {
                for (auto& p : v) {
                    float dx = p.x - 0.5f;
                    float dy = p.y - 0.5f;
                    p = CCPoint(0.5f + dy, 0.5f - dx);
                }
            }
            for (int i = 0; i < 3; i++) {
                o.tri[i] = CCPoint(
                    o.rect.origin.x + v[i].x * o.rect.size.width,
                    o.rect.origin.y + v[i].y * o.rect.size.height
                );
            }
        } else if (type == GameObjectType::Hazard && obj->m_objectRadius > 0.f) {
            o.kind = 2;
            o.center = obj->getPosition();
            o.radius = obj->m_objectRadius;
            o.rect = CCRect(o.center.x - o.radius, o.center.y - o.radius, o.radius * 2.f, o.radius * 2.f);
        }
        s_cache.push_back(o);
    }
}

static void ensureCache(GJBaseGameLayer* L, float px) {
    if (s_cacheX < -1e8f || px > s_cacheX + 250.f || px < s_cacheX - 5.f) {
        rebuildCache(L, px);
    }
}

// ======================================================================
//  INPUT
// ======================================================================
static void press(GJBaseGameLayer* L, int ch, bool down) {
    s_injecting = true;
    L->handleButton(down, 1, ch == 0);
    s_injecting = false;
}

static void releaseChannel(GJBaseGameLayer* L, int ch) {
    if (s_ctl[ch]) {
        s_ctl[ch] = false;
        s_hold[ch] = s_userHold[ch];
        press(L, ch, s_userHold[ch]);
    }
    if (s_spam[ch].down && !s_userHold[ch]) {
        s_spam[ch].down = false;
        press(L, ch, false);
    }
}

static void trackMotion(int pi, PlayerObject* p) {
    auto& m = s_motion[pi];
    float px = p->getPositionX();
    float py = p->getPositionY();
    if (m.haveLast) {
        float dx = px - m.lastX;
        float dy = py - m.lastY;
        if (dx > 0.001f && dx < 100.f) {
            m.dx = dx;
            float k = std::fabs(dy) / dx;
            if (k > 0.3f && k < 3.f) m.k = k;
        } else if (dx < -1.f || dx >= 100.f) {
            m.dx = 0.f;
            m.k = 1.f;
            s_cacheX = -1e9f;
        }
    }
    m.lastX = px;
    m.lastY = py;
    m.haveLast = true;
}

// ======================================================================
//  SENSOR BOX
// ======================================================================
struct Box {
    float hsx, hsy, ox, oy;
};

// sensor box = the game's own wave hitbox (red box) + margin
static Box makeBoxM(PlayerObject* p, float px, float py, float margin) {
    auto mod = Mod::get();
    float base = static_cast<float>(mod->getSettingValue<double>("hitbox-size"));

    Box b{0.f, 0.f, 0.f, 0.f};
    bool got = false;
    if (mod->getSettingValue<bool>("auto-hitbox")) {
        CCRect r = p->getObjectRect();
        if (r.size.width > 0.5f && r.size.width < 60.f &&
            r.size.height > 0.5f && r.size.height < 60.f) {
            b.hsx = r.size.width / 2.f + margin;
            b.hsy = r.size.height / 2.f + margin;
            b.ox = r.getMidX() - px;
            b.oy = r.getMidY() - py;
            got = true;
        }
    }
    if (!got) {
        b.hsx = b.hsy = (base * p->m_vehicleSize) / 2.f + margin;
    }
    b.hsx = std::max(0.25f, b.hsx);
    b.hsy = std::max(0.25f, b.hsy);
    return b;
}

static Box makeBox(PlayerObject* p, float px, float py) {
    return makeBoxM(p, px, py, static_cast<float>(Mod::get()->getSettingValue<double>("margin")));
}

static bool makeAgent(PlayerObject* p, int pi, bool gravityOpt, Agent& a) {
    auto& m = s_motion[pi];
    if (m.dx <= 0.01f) return false;
    float px = p->getPositionX();
    float py = p->getPositionY();
    Box b = makeBox(p, px, py);
    a.player = pi;
    a.cx0 = px + b.ox;
    a.cy0 = py + b.oy;
    a.dx = m.dx;
    a.d = m.k * m.dx;
    a.hsx = b.hsx;
    a.hsy = b.hsy;
    a.sign = (gravityOpt && p->m_isUpsideDown) ? -1.f : 1.f;
    return true;
}

// draws the sensor box in the level so it can be compared with the red hitbox
static void drawSensor(GJBaseGameLayer* L, int pi, bool show, CCRect const& r) {
    if (!L->m_objectLayer) return;
    std::string id = pi == 0 ? "wavespam-debug-1" : "wavespam-debug-2";
    auto node = static_cast<CCDrawNode*>(L->m_objectLayer->getChildByID(id));
    if (!show) {
        if (node) node->removeFromParent();
        return;
    }
    if (!node) {
        node = CCDrawNode::create();
        node->setID(id);
        L->m_objectLayer->addChild(node, 1000);
    }
    node->clear();
    CCPoint v[4] = {
        CCPoint(r.getMinX(), r.getMinY()), CCPoint(r.getMaxX(), r.getMinY()),
        CCPoint(r.getMaxX(), r.getMaxY()), CCPoint(r.getMinX(), r.getMaxY())
    };
    ccColor4F fill = pi == 0 ? ccColor4F{0.f, 1.f, 0.f, 0.15f} : ccColor4F{1.f, 0.6f, 0.f, 0.15f};
    ccColor4F line = pi == 0 ? ccColor4F{0.f, 1.f, 0.f, 1.f} : ccColor4F{1.f, 0.6f, 0.f, 1.f};
    node->drawPolygon(v, 4, fill, 0.5f, line);
}

static void hideBoxes(GJBaseGameLayer* L) {
    drawSensor(L, 0, false, CCRect());
    drawSensor(L, 1, false, CCRect());
}

// ======================================================================
//  BOT
// ======================================================================
// Sensor / Bounce: steer by looking at the level
static void runAuto(GJBaseGameLayer* L, float dt, bool bounce, bool twoP, bool dual) {
    auto mod = Mod::get();
    bool useP[2] = {mod->getSettingValue<bool>("player1"), mod->getSettingValue<bool>("player2")};
    bool gravityOpt = mod->getSettingValue<bool>("gravity-portals");
    bool show = mod->getSettingValue<bool>("show-sensor");
    float threshold = std::clamp(static_cast<float>(mod->getSettingValue<double>("threshold")), 0.f, 1.f);
    float lookahead = static_cast<float>(mod->getSettingValue<double>("lookahead"));
    float extra = std::max(0.f, static_cast<float>(mod->getSettingValue<double>("touch-distance")));
    PlayerObject* pl[2] = {L->m_player1, L->m_player2};

    std::vector<Agent> chan[2];
    for (int pi = 0; pi < 2; pi++) {
        auto p = pl[pi];
        if (!p || p->m_isDead || !p->m_isDart) continue;
        if (!useP[pi]) continue;
        if (pi == 1 && !dual) continue;
        Agent a;
        if (!makeAgent(p, pi, gravityOpt, a)) continue;
        chan[(twoP && pi == 1) ? 1 : 0].push_back(std::move(a));
    }

    // level data around the first steered player
    for (int c = 0; c < 2; c++) {
        if (!chan[c].empty()) {
            ensureCache(L, chan[c][0].cx0);
            break;
        }
    }

    bool shown[2] = {false, false};

    for (int c = 0; c < 2; c++) {
        if (c == 1 && !twoP) break;
        auto& agents = chan[c];

        if (agents.empty()) {
            releaseChannel(L, c);
            continue;
        }

        if (!s_ctl[c]) {
            s_ctl[c] = true;
            s_hold[c] = s_userHold[c];
        }

        bool hold = s_hold[c];

        if (!bounce) {
            int H = std::clamp(static_cast<int>(std::ceil(lookahead / std::max(dt, 0.0005f))), 4, 70);
            for (auto& a : agents) {
                filterObs(s_cache, a.obs,
                          a.cx0 - a.hsx, a.cx0 + H * a.dx + a.hsx,
                          a.cy0 - H * a.d - a.hsy, a.cy0 + H * a.d + a.hsy);
            }
            hold = planHold(agents, H, s_hold[c], threshold);
        } else {
            int pick = 0;
            bool pickUrgent = false;
            for (auto& a : agents) {
                float probe = extra + a.d;
                filterObs(s_cache, a.obs,
                          a.cx0 - a.hsx - 2.f, a.cx0 + a.dx + a.hsx + 2.f,
                          a.cy0 - a.hsy - probe - 2.f, a.cy0 + a.hsy + probe + 2.f);
                bool curUp = s_hold[c] ? (a.sign > 0.f) : (a.sign < 0.f);
                Vote v = bounceVote(a, probe, curUp);
                if (v.v == 0) continue;
                if (pick == 0 || (v.urgent && !pickUrgent)) {
                    pick = v.v;
                    pickUrgent = v.urgent;
                }
            }
            if (pick != 0) hold = pick > 0;
        }

        if (hold != s_hold[c]) {
            s_hold[c] = hold;
            press(L, c, hold);
        }

        for (auto& a : agents) {
            shown[a.player] = true;
            drawSensor(L, a.player, show,
                       CCRect(a.cx0 - a.hsx, a.cy0 - a.hsy, 2.f * a.hsx, 2.f * a.hsy));
        }
    }

    for (int pi = 0; pi < 2; pi++) {
        if (!shown[pi]) drawSensor(L, pi, false, CCRect());
    }
}

// CPS / Frames: plain spam
static void runSpam(GJBaseGameLayer* L, float dt, std::string const& mode, bool twoP, bool dual) {
    auto mod = Mod::get();
    bool useP[2] = {mod->getSettingValue<bool>("player1"), mod->getSettingValue<bool>("player2")};
    bool onlyWave = mod->getSettingValue<bool>("only-wave");
    bool holdMode = mod->getSettingValue<bool>("hold-to-spam");
    PlayerObject* pl[2] = {L->m_player1, L->m_player2};

    for (int c = 0; c < 2; c++) {
        if (c == 1 && !twoP) break;

        if (s_ctl[c]) releaseChannel(L, c); // came from Sensor / Bounce

        bool any = false, anyWave = false;
        for (int pi = 0; pi < 2; pi++) {
            if (!useP[pi]) continue;
            if (pi == 1 && !dual) continue;
            if (((twoP && pi == 1) ? 1 : 0) != c) continue;
            any = true;
            if (pl[pi] && !pl[pi]->m_isDead && pl[pi]->m_isDart) anyWave = true;
        }

        auto& sp = s_spam[c];
        bool active = any && (!onlyWave || anyWave) && (!holdMode || s_userHold[c]);

        if (!active) {
            if (sp.down && !s_userHold[c]) {
                sp.down = false;
                press(L, c, false);
            }
            continue;
        }

        bool toggle = false;
        if (mode == "Frames") {
            int n = std::max<int>(1, static_cast<int>(mod->getSettingValue<int64_t>("frames")));
            if (++sp.frames >= n) {
                sp.frames = 0;
                toggle = true;
            }
        } else {
            float cps = std::max(1.f, static_cast<float>(mod->getSettingValue<double>("cps")));
            float half = 1.f / (2.f * cps);
            sp.accum += dt;
            if (sp.accum >= half) {
                sp.accum -= half;
                if (sp.accum > half) sp.accum = 0.f;
                toggle = true;
            }
        }

        if (toggle) {
            sp.down = !sp.down;
            press(L, c, sp.down);
        }
    }
}

// ======================================================================
//  CLICK WINDOW
//  Every click is measured the moment the next click arrives: how many
//  frames earlier / later could it have been pressed and still survive?
// ======================================================================
static void cwRedraw(GJBaseGameLayer* L) {
    if (!L || !L->m_objectLayer) return;
    auto mod = Mod::get();
    bool circles = mod->getSettingValue<bool>("cw-circles");
    bool lines = mod->getSettingValue<bool>("cw-lines");
    float radius = static_cast<float>(mod->getSettingValue<double>("cw-size"));

    auto node = static_cast<CCDrawNode*>(L->m_objectLayer->getChildByID("wavespam-cw"));
    if (s_meas.empty() || (!circles && !lines)) {
        if (node) node->removeFromParent();
        return;
    }
    if (!node) {
        node = CCDrawNode::create();
        node->setID("wavespam-cw");
        L->m_objectLayer->addChild(node, 999);
    }
    node->clear();
    if (lines) {
        for (auto const& m : s_meas)
            for (auto const& sg : m.segs) node->drawSegment(sg.a, sg.b, 0.35f, sg.c);
    }
    if (circles) {
        for (auto const& m : s_meas)
            for (auto const& dt : m.dots) node->drawDot(dt.p, radius, dt.c);
    }
}

static void cwUpdateHud(bool show) {
    auto pl = PlayLayer::get();
    if (!pl || !pl->m_uiLayer) return;
    auto node = static_cast<CCLabelBMFont*>(pl->m_uiLayer->getChildByID("wavespam-cw-hud"));
    if (!show) {
        if (node) node->setVisible(false);
        return;
    }
    if (!node) {
        node = CCLabelBMFont::create("", "bigFont.fnt");
        node->setID("wavespam-cw-hud");
        node->setScale(0.4f);
        node->setAlignment(kCCTextAlignmentCenter);
        auto win = CCDirector::get()->getWinSize();
        node->setPosition({win.width / 2.f, win.height - 42.f});
        pl->m_uiLayer->addChild(node, 50);
    }
    node->setString(s_cwHud.c_str());
    node->setColor(s_cwHudColor);
    node->setVisible(true);
}

static void cwMeasure(GJBaseGameLayer* L, int pi, long e0, long e1, long e2) {
    auto& c = s_cw[pi];
    auto mod = Mod::get();
    int range = std::clamp(static_cast<int>(std::lround(mod->getSettingValue<double>("cw-range"))), 1, 80);
    float extraSec = static_cast<float>(mod->getSettingValue<double>("cw-extra"));
    float keep = static_cast<float>(mod->getSettingValue<double>("cw-keep"));
    int E = std::clamp(static_cast<int>(std::ceil(extraSec / std::max(s_cwDt, 0.0005f))), 0, 60);

    CwCtx ctx;
    if (!cwSetup(ctx, c.h, c.baseTick, e0, e1, e2, range, E, s_cache)) return;
    CwResult r = cwWindow(ctx);

    int W = r.zeroSafe ? r.a + r.b + 1 : 0;
    bool capped = r.a == ctx.Lmax || r.b == ctx.Rmax;

    // ---- drawing data
    CwMeas m;
    m.expire = s_cwTime + std::max(0.2f, keep);

    for (long dlt = -ctx.Lmax; dlt <= ctx.Rmax; dlt++) {
        auto const& T = ctx.at(e1 + dlt);
        CCPoint pos(T.x + ctx.ox, T.y + ctx.oy);
        bool sf = r.safe[static_cast<size_t>(dlt + ctx.Lmax)] != 0;
        ccColor4F col = {0.55f, 0.55f, 0.55f, 0.8f};
        if (!sf) {
            col = ccColor4F{1.f, 0.15f, 0.15f, 0.95f};
        } else if (r.zeroSafe && dlt >= -r.a && dlt <= r.b) {
            float half = std::max(1.f, static_cast<float>(r.a + r.b) / 2.f);
            float mid = static_cast<float>(r.b - r.a) / 2.f;
            float k = 1.f - std::min(1.f, std::fabs(static_cast<float>(dlt) - mid) / half);
            col = ccColor4F{1.f - k, 1.f, 0.f, 0.95f}; // yellow at the edges, green in the middle
        }
        m.dots.push_back({pos, col});
    }

    auto addPath = [&](std::vector<CCPoint> const& pts, ccColor4F col) {
        for (size_t i = 1; i < pts.size(); i++) m.segs.push_back({pts[i - 1], pts[i], col});
    };

    // the real path
    {
        std::vector<CCPoint> pts;
        for (long t = ctx.ts; t <= ctx.tn; t++) {
            auto const& T = ctx.at(t);
            pts.push_back(CCPoint(T.x + ctx.ox, T.y + ctx.oy));
        }
        addPath(pts, ccColor4F{1.f, 1.f, 1.f, 0.7f});
    }
    if (r.zeroSafe) {
        if (r.a > 0) {
            std::vector<CCPoint> pts;
            ctx.simulate(-r.a, &pts);
            addPath(pts, ccColor4F{0.2f, 0.9f, 1.f, 0.9f});          // earliest safe click
        }
        if (r.b > 0) {
            std::vector<CCPoint> pts;
            ctx.simulate(r.b, &pts);
            addPath(pts, ccColor4F{1.f, 0.65f, 0.1f, 0.9f});         // latest safe click
        }
        if (r.b + 1 <= ctx.Rmax) {
            std::vector<CCPoint> pts;
            ctx.simulate(r.b + 1, &pts);
            addPath(pts, ccColor4F{1.f, 0.1f, 0.1f, 0.9f});          // first failing click
        }
        if (r.a + 1 <= ctx.Lmax) {
            std::vector<CCPoint> pts;
            ctx.simulate(-(r.a + 1), &pts);
            addPath(pts, ccColor4F{1.f, 0.1f, 0.1f, 0.9f});
        }
    }
    s_meas.push_back(std::move(m));
    while (s_meas.size() > 6) s_meas.pop_front();

    // ---- stats + HUD text
    if (W > 0) {
        s_cwStats.clicks++;
        s_cwStats.sum += W;
        s_cwStats.minW = s_cwStats.clicks == 1 ? W : std::min(s_cwStats.minW, W);
        if (W == 1) s_cwStats.fp++;
    }
    float ms = static_cast<float>(W) * s_cwDt * 1000.f;
    std::string l1;
    if (W == 0) l1 = "WINDOW ?";
    else if (W == 1) l1 = fmt::format("FRAME PERFECT  1f  {:.1f}ms", ms);
    else l1 = fmt::format("WINDOW {}f{}  (-{} / +{})  {:.1f}ms", W, capped ? "+" : "", r.a, r.b, ms);
    std::string l2 = s_cwStats.clicks > 0
        ? fmt::format("avg {:.1f}f   min {}f   FP {}/{}",
                      s_cwStats.sum / s_cwStats.clicks, s_cwStats.minW, s_cwStats.fp, s_cwStats.clicks)
        : std::string("");
    s_cwHud = l2.empty() ? l1 : l1 + "\n" + l2;
    s_cwHudColor = W == 0 ? ccColor3B{170, 170, 170}
                 : W == 1 ? ccColor3B{255, 90, 90}
                 : W <= 3 ? ccColor3B{255, 210, 60}
                          : ccColor3B{90, 255, 120};
    s_cwHudUntil = s_cwTime + std::max(0.2f, keep);

    cwRedraw(L);
    if (mod->getSettingValue<bool>("cw-hud")) cwUpdateHud(true);
}

static void cwRecord(GJBaseGameLayer* L, int pi, PlayerObject* p, bool hold) {
    auto& c = s_cw[pi];
    auto const& m = s_motion[pi];
    float px = p->getPositionX();
    float py = p->getPositionY();
    float margin = static_cast<float>(Mod::get()->getSettingValue<double>("cw-margin"));
    Box b = makeBoxM(p, px, py, margin);

    CwTick t;
    t.x = px;
    t.y = py;
    t.dx = m.dx;
    t.d = m.k * m.dx;
    t.sign = p->m_isUpsideDown ? -1.f : 1.f;
    t.hold = hold;
    t.hsx = b.hsx;
    t.hsy = b.hsy;
    t.ox = b.ox;
    t.oy = b.oy;

    bool change = !c.h.empty() && c.h.back().hold != hold;
    c.h.push_back(t);
    if (c.h.size() > 1500) {
        c.h.pop_front();
        c.baseTick++;
    }

    if (!change) return;

    long tn = c.baseTick + static_cast<long>(c.h.size()) - 1;
    if (c.evCount >= 1) {
        long e1 = c.ev[1];
        long e0 = c.evCount >= 2 ? c.ev[0] : -1;
        cwMeasure(L, pi, e0, e1, tn);
        c.ev[0] = c.ev[1];
        c.ev[1] = tn;
        c.evCount = 2;
    } else {
        c.ev[1] = tn;
        c.evCount = 1;
    }
}

static void cwClearVisuals(GJBaseGameLayer* L) {
    if (!s_meas.empty()) {
        s_meas.clear();
        cwRedraw(L);
    }
    cwUpdateHud(false);
}

static void cwTick(GJBaseGameLayer* L, float dt, bool twoP, bool dual) {
    auto mod = Mod::get();
    if (!mod->getSettingValue<bool>("cw-enabled")) {
        s_cw[0] = CwPlayer();
        s_cw[1] = CwPlayer();
        cwClearVisuals(L);
        return;
    }

    s_cwTime += dt;
    s_cwDt = dt;

    bool expired = false;
    while (!s_meas.empty() && s_meas.front().expire < s_cwTime) {
        s_meas.pop_front();
        expired = true;
    }
    if (expired) cwRedraw(L);
    if (s_cwHudUntil >= 0.f && s_cwTime > s_cwHudUntil) {
        s_cwHudUntil = -1.f;
        cwUpdateHud(false);
    }

    bool useP[2] = {true, mod->getSettingValue<bool>("cw-player2")};
    PlayerObject* pl[2] = {L->m_player1, L->m_player2};

    for (int pi = 0; pi < 2; pi++) {
        auto p = pl[pi];
        auto& c = s_cw[pi];
        if (!p || p->m_isDead || !p->m_isDart || !useP[pi] || (pi == 1 && !dual)) {
            if (!c.h.empty() || c.evCount != 0) c = CwPlayer();
            continue;
        }
        if (s_motion[pi].dx <= 0.01f) continue;

        ensureCache(L, p->getPositionX());
        int ch = (twoP && pi == 1) ? 1 : 0;
        bool hold = s_ctl[ch] ? s_hold[ch] : s_spam[ch].down;
        cwRecord(L, pi, p, hold);
    }
}

static void tick(GJBaseGameLayer* L, float dt) {
    auto p1 = L->m_player1;
    auto p2 = L->m_player2;
    if (!p1 || p1->m_isDead) return;

    trackMotion(0, p1);
    if (p2) trackMotion(1, p2);

    auto mod = Mod::get();
    bool twoP = L->m_levelSettings && L->m_levelSettings->m_twoPlayerMode;
    bool dual = p2 && p2->isVisible();
    s_twoP = twoP;

    if (!mod->getSettingValue<bool>("enabled")) {
        releaseChannel(L, 0);
        releaseChannel(L, 1);
        hideBoxes(L);
        cwTick(L, dt, twoP, dual);
        return;
    }

    auto mode = mod->getSettingValue<std::string>("mode");
    if (mode == "Sensor") {
        runAuto(L, dt, false, twoP, dual);
    } else if (mode == "Bounce") {
        runAuto(L, dt, true, twoP, dual);
    } else {
        runSpam(L, dt, mode, twoP, dual);
        hideBoxes(L);
    }
    cwTick(L, dt, twoP, dual);
}

// ======================================================================
//  HOOKS
// ======================================================================
class $modify(WaveSpamGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        if (!s_injecting && button == 1) {
            int c = (s_twoP && !isPlayer1) ? 1 : 0;
            s_userHold[c] = down;
            if (s_ctl[c]) return; // the bot is steering this input, ignore the finger
            s_spam[c].down = down;
            s_spam[c].accum = 0.f;
            s_spam[c].frames = 0;
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (!isHalfTick) tick(this, dt);
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

class $modify(WaveSpamPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        resetState();
        s_cwStats = CwStats();
        return true;
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        resetState();
    }
};

// ======================================================================
//  PAUSE MENU
// ======================================================================
// while the menu is open, the pause screen's own menus ignore touches
static void setPauseMenusEnabled(CCNode* pause, bool enabled) {
    auto kids = pause->getChildren();
    if (!kids) return;
    for (auto child : CCArrayExt<CCNode*>(kids)) {
        if (auto m = typeinfo_cast<CCMenu*>(child)) m->setEnabled(enabled);
    }
}

// ---------------------------------------------------------------------
// The WS icon: tap = open the menu, hold and drag = move it anywhere
// (the place is remembered), so it never gets in the way of other buttons.
// ---------------------------------------------------------------------
static constexpr char const* DISCORD_URL = "https://discord.gg/y88pg4hwU";
static constexpr char const* MOD_VERSION = "v3.0.0";

// short guide shown by the Help button
static constexpr char const* HELP_TEXT =
    "<cy>How to use</c>\n"
    "Tap the WS icon in the pause menu to open this menu. Hold and drag the icon to move it.\n\n"
    "<cy>Options</c>\n"
    "Enabled: turns the mod on or off (a check mark shows it is on).\n"
    "Mode: Bounce turns away from the slope it touches. Sensor looks ahead and steers. CPS and Frames are plain spam.\n"
    "Player 1 / Player 2: which wave it steers in dual.\n"
    "Gravity: follows gravity portals.\n"
    "Show Box: draws the sensor so you can compare it with the hitbox.\n"
    "Touch and Margin: set both to 0 if it presses too early.\n"
    "Threshold: higher means fewer clicks. Look Ahead: how far Sensor looks.\n"
    "Settings: the full list of options.\n\n"
    "Need more help? Press Discord.";

class WsIcon : public CCLayer {
public:
    CCNode* m_icon = nullptr;
    std::function<void()> m_onTap;
    bool m_dragging = false;
    CCPoint m_start;
    CCPoint m_grab;

    static WsIcon* create(CCNode* icon, std::function<void()> onTap) {
        auto r = new WsIcon();
        if (r && r->init(icon, std::move(onTap))) {
            r->autorelease();
            return r;
        }
        CC_SAFE_DELETE(r);
        return nullptr;
    }

    bool init(CCNode* icon, std::function<void()> onTap) {
        if (!CCLayer::init()) return false;
        m_icon = icon;
        m_onTap = std::move(onTap);
        this->addChild(icon);
        this->setTouchEnabled(true);
        return true;
    }

    void registerWithTouchDispatcher() override {
        // only claims a touch that starts on the icon, everything else passes through
        CCTouchDispatcher::get()->addTargetedDelegate(this, -400, true);
    }

    bool ccTouchBegan(CCTouch* t, CCEvent*) override {
        if (!m_icon || !m_icon->isVisible()) return false;
        auto p = this->convertToNodeSpace(t->getLocation());
        auto box = m_icon->boundingBox();
        box.origin.x -= 8.f;
        box.origin.y -= 8.f;
        box.size.width += 16.f;
        box.size.height += 16.f;
        if (!box.containsPoint(p)) return false;
        m_dragging = false;
        m_start = p;
        m_grab = CCPoint(m_icon->getPositionX() - p.x, m_icon->getPositionY() - p.y);
        return true;
    }

    void ccTouchMoved(CCTouch* t, CCEvent*) override {
        auto p = this->convertToNodeSpace(t->getLocation());
        float dx = p.x - m_start.x;
        float dy = p.y - m_start.y;
        if (!m_dragging && std::sqrt(dx * dx + dy * dy) < 6.f) return;
        m_dragging = true;
        auto win = CCDirector::get()->getWinSize();
        float x = std::clamp(p.x + m_grab.x, 14.f, win.width - 14.f);
        float y = std::clamp(p.y + m_grab.y, 14.f, win.height - 14.f);
        m_icon->setPosition({x, y});
    }

    void ccTouchEnded(CCTouch*, CCEvent*) override {
        if (m_dragging) {
            Mod::get()->setSavedValue<float>("icon-x", m_icon->getPositionX());
            Mod::get()->setSavedValue<float>("icon-y", m_icon->getPositionY());
        } else if (m_onTap) {
            m_onTap();
        }
        m_dragging = false;
    }

    void ccTouchCancelled(CCTouch*, CCEvent*) override {
        m_dragging = false;
    }
};

// the WS image (falls back to a plain "WS" button if the image is missing),
// with a check mark in the corner while the mod is enabled
static CCNode* makeWsIcon(bool on) {
    CCNode* icon = nullptr;
    std::string path = fmt::format("{}/ws_icon.png", GEODE_MOD_ID);
    if (geode::cocos::fileExistsInSearchPaths(path.c_str())) {
        if (auto spr = CCSprite::create(path.c_str())) {
            auto sz = spr->getContentSize();
            float big = std::max(sz.width, sz.height);
            spr->setScale(big > 0.f ? 30.f / big : 1.f);
            icon = spr;
        }
    }
    if (!icon) {
        auto b = ButtonSprite::create("WS");
        b->setScale(0.5f);
        icon = b;
    }

    if (auto tick = CCSprite::createWithSpriteFrameName("GJ_checkOn_001.png")) {
        auto sz = icon->getContentSize();
        float sc = icon->getScale() > 0.f ? icon->getScale() : 1.f;
        tick->setScale(0.6f / sc);
        tick->setPosition({sz.width, sz.height});
        tick->setID("wavespam-check");
        tick->setVisible(on);
        icon->addChild(tick, 5);
    }
    return icon;
}

class $modify(WaveSpamPause, PauseLayer) {
    // custom menu
    void openWavePanel() {
        if (auto old = this->getChildByID("wavespam-panel")) {
            setPauseMenusEnabled(this, true);
            old->removeFromParent();
            return;
        }

        setPauseMenusEnabled(this, false);

        auto win = CCDirector::get()->getWinSize();
        float cx = win.width / 2.f;
        float cy = win.height / 2.f;

        auto panel = CCLayer::create();
        panel->setID("wavespam-panel");

        auto bg = CCScale9Sprite::create("GJ_square01.png");
        bg->setContentSize({400.f, 230.f});
        bg->setPosition({cx, cy});
        panel->addChild(bg);

        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        panel->addChild(menu);

        auto addLabel = [&](char const* text, float x, float y, float scale, bool left) {
            auto l = CCLabelBMFont::create(text, "bigFont.fnt");
            l->setScale(scale);
            if (left) l->setAnchorPoint({0.f, 0.5f});
            l->setPosition({x, y});
            panel->addChild(l);
            return l;
        };

        addLabel("Wave Spam", cx, cy + 95.f, 0.6f, false);

        float rowY[5] = {cy + 62.f, cy + 34.f, cy + 6.f, cy - 22.f, cy - 50.f};

        // ON/OFF row with a check mark that shows while it is ON
        auto addToggle = [&](char const* key, char const* name, float labelX, float toggleX, float y,
                             std::function<void(bool)> onChange = nullptr) {
            addLabel(name, labelX, y, 0.45f, true);

            auto offSpr = ButtonSprite::create("OFF");
            auto onSpr = ButtonSprite::create("ON");
            offSpr->setScale(0.5f);
            onSpr->setScale(0.5f);

            bool cur = Mod::get()->getSettingValue<bool>(key);
            CCSprite* tick = CCSprite::createWithSpriteFrameName("GJ_checkOn_001.png");
            if (tick) {
                tick->setScale(0.55f);
                tick->setPosition({toggleX - 34.f, y});
                tick->setVisible(cur);
                panel->addChild(tick);
            }

            auto t = CCMenuItemExt::createToggler(onSpr, offSpr, [key, tick, onChange](CCMenuItemToggler* tg) {
                bool nowOn = !tg->isToggled();
                Mod::get()->setSettingValue<bool>(key, nowOn);
                if (tick) tick->setVisible(nowOn);
                if (onChange) onChange(nowOn);
            });
            t->toggle(cur);
            t->setPosition({toggleX, y});
            menu->addChild(t);
        };

        // +/- row
        auto addStepper = [&](char const* key, char const* name, float labelX, float valX, float y,
                              double step, double lo, double hi, int dec) {
            addLabel(name, labelX, y, 0.45f, true);

            auto val = addLabel(
                fmt::format("{:.{}f}", Mod::get()->getSettingValue<double>(key), dec).c_str(),
                valX, y, 0.45f, false
            );

            auto change = [val, key, lo, hi, dec](double delta) {
                double v = Mod::get()->getSettingValue<double>(key) + delta;
                v = std::clamp(v, lo, hi);
                double p10 = std::pow(10.0, dec);
                v = std::round(v * p10) / p10;
                Mod::get()->setSettingValue<double>(key, v);
                val->setString(fmt::format("{:.{}f}", v, dec).c_str());
            };

            auto minusSpr = ButtonSprite::create("-");
            minusSpr->setScale(0.5f);
            auto minus = CCMenuItemExt::createSpriteExtra(minusSpr, [change, step](auto) { change(-step); });
            minus->setPosition({valX - 30.f, y});
            menu->addChild(minus);

            auto plusSpr = ButtonSprite::create("+");
            plusSpr->setScale(0.5f);
            auto plus = CCMenuItemExt::createSpriteExtra(plusSpr, [change, step](auto) { change(step); });
            plus->setPosition({valX + 30.f, y});
            menu->addChild(plus);
        };

        // left column
        float lx = cx - 188.f;
        float lt = cx - 32.f;
        addToggle("enabled", "Enabled", lx, lt, rowY[0], [this](bool on) {
            if (auto tick = this->getChildByIDRecursive("wavespam-check")) tick->setVisible(on);
        });
        addToggle("player1", "Player 1", lx, lt, rowY[1]);
        addToggle("player2", "Player 2", lx, lt, rowY[2]);
        addToggle("gravity-portals", "Gravity", lx, lt, rowY[3]);
        addToggle("show-sensor", "Show Box", lx, lt, rowY[4]);

        // right column
        float rx = cx + 12.f;
        float rv = cx + 138.f;

        addLabel("Mode", rx, rowY[0], 0.45f, true);
        auto modeSpr = ButtonSprite::create(Mod::get()->getSettingValue<std::string>("mode").c_str());
        modeSpr->setScale(0.5f);
        auto modeBtn = CCMenuItemExt::createSpriteExtra(modeSpr, [modeSpr](auto) {
            static char const* modes[4] = {"Bounce", "Sensor", "CPS", "Frames"};
            auto cur = Mod::get()->getSettingValue<std::string>("mode");
            int idx = 0;
            for (int i = 0; i < 4; i++) if (cur == modes[i]) idx = i;
            idx = (idx + 1) % 4;
            Mod::get()->setSettingValue<std::string>("mode", modes[idx]);
            modeSpr->setString(modes[idx]);
        });
        modeBtn->setPosition({rv, rowY[0]});
        menu->addChild(modeBtn);

        addStepper("touch-distance", "Touch", rx, rv, rowY[1], 0.5, 0.0, 20.0, 1);
        addStepper("margin", "Margin", rx, rv, rowY[2], 0.5, -10.0, 20.0, 1);
        addStepper("threshold", "Threshold", rx, rv, rowY[3], 0.05, 0.0, 1.0, 2);
        addStepper("lookahead", "Look Ahead", rx, rv, rowY[4], 0.02, 0.03, 0.4, 2);

        // bottom row: Help, Discord, Settings (the Geode list), Close
        auto helpSpr = ButtonSprite::create("Help");
        helpSpr->setScale(0.5f);
        auto helpBtn = CCMenuItemExt::createSpriteExtra(helpSpr, [](auto) {
            FLAlertLayer::create("Help", HELP_TEXT, "OK")->show();
        });
        helpBtn->setPosition({cx - 111.f, cy - 86.f});
        menu->addChild(helpBtn);

        auto discordSpr = ButtonSprite::create("Discord");
        discordSpr->setScale(0.5f);
        auto discordBtn = CCMenuItemExt::createSpriteExtra(discordSpr, [](auto) {
            geode::utils::web::openLinkInBrowser(DISCORD_URL);
        });
        discordBtn->setPosition({cx - 47.f, cy - 86.f});
        menu->addChild(discordBtn);

        auto setSpr = ButtonSprite::create("Settings");
        setSpr->setScale(0.5f);
        auto setBtn = CCMenuItemExt::createSpriteExtra(setSpr, [](auto) {
            openSettingsPopup(Mod::get(), false);
        });
        setBtn->setPosition({cx + 32.f, cy - 86.f});
        menu->addChild(setBtn);

        auto closeSpr = ButtonSprite::create("Close");
        closeSpr->setScale(0.5f);
        auto closeBtn = CCMenuItemExt::createSpriteExtra(closeSpr, [this, panel](auto) {
            setPauseMenusEnabled(this, true);
            panel->removeFromParent();
        });
        closeBtn->setPosition({cx + 106.f, cy - 86.f});
        menu->addChild(closeBtn);

        this->addChild(panel, 2000);

        // "New update" message, shown once after each update
        auto seen = Mod::get()->getSavedValue<std::string>("seen-update", "");
        if (seen != MOD_VERSION) {
            Mod::get()->setSavedValue<std::string>("seen-update", MOD_VERSION);
            FLAlertLayer::create(
                "New update",
                "<cy>What's new in v3.0.0</c>\n"
                "- Geometry Dash 2.2091 and Geode 6 support\n"
                "- Works on Windows, macOS, iOS and Android\n"
                "- Help button: explains every option\n"
                "- Discord button: questions and bug reports\n"
                "- Draggable WS icon, Settings inside this menu\n"
                "- Bounce and Sensor modes, Player 1 / 2, gravity portals",
                "OK"
            )->show();
        }
    }

    void customSetup() {
        PauseLayer::customSetup();

        auto winSize = CCDirector::get()->getWinSize();
        bool on = Mod::get()->getSettingValue<bool>("enabled");

        auto icon = makeWsIcon(on);
        float x = Mod::get()->getSavedValue<float>("icon-x", 112.f);
        float y = Mod::get()->getSavedValue<float>("icon-y", winSize.height - 107.f);
        icon->setPosition({x, y});

        auto layer = WsIcon::create(icon, [this]() { this->openWavePanel(); });
        if (layer) this->addChild(layer, 1000);
    }
};
