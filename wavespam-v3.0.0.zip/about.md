# Wave Spam

Wave autopilot for slopes, for **Geometry Dash 2.2091** and **Geode 6**.

In the pause menu tap the **WS** icon to open the menu (hold and drag the icon to move it; a check mark on it means the mod is on). The menu has **Help**, **Discord** and **Settings** buttons.

- **Bounce**: touches the slope above -> goes down, touches the slope below -> goes up.
- **Sensor**: looks ahead and steers through gaps.
- **CPS / Frames**: plain spam.
- **Player 1 / Player 2**: choose which wave the bot steers in dual.
- **Gravity**: works when the wave is upside down.

Questions or bugs: https://discord.gg/y88pg4hwU

Original by yausaf
