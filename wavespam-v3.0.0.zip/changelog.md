# v3.0.0

- Updated for Geometry Dash 2.2091 and Geode 6 (Windows, macOS, iOS, Android)
- New Help button in the menu that explains every option
- New Discord button
- The "New update" message shows once per version
- For Geometry Dash 2.2081 and Geode 5 keep using v2.5.0

# v2.5.0

- New WS icon (your image) in the pause menu: tap to open the menu, hold and drag to move it, a check mark shows when the mod is on
- The Settings button is now inside the menu
- "New update" message with the list of features, shown once after each update

# v2.4.0

- The original menu look is back (brown panel, same buttons), with the new features added as rows: Player 1, Player 2, Gravity, Threshold, Look Ahead
- Check marks show which options are ON, also on the Spam button in the pause menu
- Pause buttons ignore touches while the menu is open

# v2.3.0

- Back to the v1.1.1 buttons: only the Spam ON/OFF button inside the level; no pause-menu buttons or custom menu
- All the newer features stay (Bounce, Player 1 / 2, gravity portals, touch distance, show sensor box, auto hitbox), set from the mod settings

# v2.2.0

- The custom menu is back (crash fixed: no touch priority changes)
- Toggles are check boxes: green check = ON, empty box = OFF; the Spam button shows a check mark while the mod is enabled
- While the menu is open the pause buttons (including Settings) ignore touches

# v2.1.1

- Removed the custom menu (it crashed the game when opened). One small Spam button in the pause menu opens the normal mod settings list; it is green while the mod is enabled

# v2.1.0

- Menu colors fixed (flat colored boxes instead of the black sprite): green ON / gray OFF, red/green status pill in the header
- The menu is now modal: nothing underneath (Settings, pause buttons) can be pressed while it is open
- The Spam button in the pause menu is green while the mod is enabled

# v2.0.3

- Required Geode version raised to 5.9.0 (fixes the packaging error about Zstd compression)

# v2.0.2

- Removed the custom font; the menu uses the game's font
- Fix build error

# v2.0.1

- Fix: pause menu could close the game when the custom font failed to load. The font is now checked first and falls back to the game's font; boxes fall back to plain rectangles
- New setting: Custom Font (on/off)

# v2.0.0

- Player 1 / Player 2 switches (dual and 2-player levels)
- Gravity portal support (inverted button when the wave is upside down)
- New custom menu with the uploaded font (Roboto Mono Italic), two columns: control and tuning
- Pause buttons restyled with the same font

# v1.5.3

- Bounce: no more early spam. Default margin 0 and touch distance 0 (it always looks exactly one step ahead); alternating only when the sensor really overlaps slopes on both sides
- New Show Sensor Box option (also in the Spam menu) to compare the sensor with the red hitbox

# v1.5.2

- Pause buttons moved to the left side of the pause screen

# v1.5.1

- Pause buttons moved left of the top-right icon button and drawn on top of other buttons

# v1.5.0

- New Bounce mode: touches the slope above -> goes down, touches the slope below -> goes up
- Custom menu (ON/OFF, mode, touch distance, margin) with its own button next to the Settings button in the pause menu

# v1.4.0

- Sensor now uses the wave's real hitbox (the red box) from the game, mini and big, plus the margin

# v1.3.1

- Sensor size can now go as low as 0.1 and margin can be negative, for very small gaps

# v1.3.0

- Sensor mode: new Switch Threshold setting to control how often it switches direction (fewer clicks)

# v1.2.1

- One small button in the pause menu that opens the mod menu (Enabled switch + settings)

# v1.2.0

- Settings and ON/OFF switch moved to a button in the pause menu

# v1.1.1

- Fix build: processCommands signature

# v1.1.0

- New Sensor mode: looks ahead for gaps and steers the wave (blocks, spikes, saws, slopes)

# v1.0.0

- First release
