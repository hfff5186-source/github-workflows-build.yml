# Wave Spam

Wave autopilot with a **Spam ON/OFF** button inside the level.

- **Sensor mode**: a box slightly bigger than the wave hitbox looks ahead and steers through gaps (mini and big wave).
- **CPS / Frames modes**: plain spam at a fixed rate.

Original by yausaf
