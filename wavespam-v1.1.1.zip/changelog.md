# v1.1.0

- New Sensor mode: looks ahead for gaps and steers the wave (blocks, spikes, saws, slopes)
- Sensor size follows mini / big wave, with an adjustable margin

# v1.0.0

- First release: auto wave spam, adjustable rate, ON/OFF button
