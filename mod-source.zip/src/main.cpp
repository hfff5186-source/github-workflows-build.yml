#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <cmath>
#include <set>
#include <utility>

using namespace geode::prelude;

constexpr float GRID = 30.f;

using Cell = std::pair<int, int>;

struct Side {
    int dx, dy;
    float rot;
};

// up, right, down, left
static const Side SIDES[4] = {
    {0, 1, 0.f},
    {1, 0, 90.f},
    {0, -1, 180.f},
    {-1, 0, 270.f},
};

static void autoEdges(EditorUI* ui) {
    auto editor = LevelEditorLayer::get();
    auto sel = ui->getSelectedObjects();

    if (!editor || !sel || sel->count() == 0) {
        FLAlertLayer::create("Auto Edge", "Select some blocks first!", "OK")->show();
        return;
    }

    int edgeId = static_cast<int>(Mod::get()->getSettingValue<int64_t>("edge-id"));
    int cornerId = static_cast<int>(Mod::get()->getSettingValue<int64_t>("corner-id"));
    float offset = static_cast<float>(Mod::get()->getSettingValue<double>("offset"));

    // 1) selected solid blocks -> grid cells
    std::set<Cell> cells;
    for (auto obj : CCArrayExt<GameObject*>(sel)) {
        if (obj->m_objectType != GameObjectType::Solid) continue;
        auto p = obj->getPosition();
        cells.insert({
            static_cast<int>(std::round(p.x / GRID)),
            static_cast<int>(std::round(p.y / GRID))
        });
    }

    if (cells.empty()) {
        FLAlertLayer::create("Auto Edge", "No solid blocks in the selection.", "OK")->show();
        return;
    }

    int placed = 0;

    // 2) every exposed side gets an edge object
    for (auto const& [gx, gy] : cells) {
        CCPoint center = {gx * GRID, gy * GRID};
        bool empty[4];

        for (int i = 0; i < 4; i++) {
            auto const& s = SIDES[i];
            empty[i] = !cells.count({gx + s.dx, gy + s.dy});

            if (empty[i]) {
                CCPoint pos = center + CCPoint(s.dx, s.dy) * offset;
                if (auto o = editor->createObject(edgeId, pos, false)) {
                    o->setRotation(s.rot);
                    placed++;
                }
            }
        }

        // 3) outer corners: two neighbouring sides both exposed
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            if (empty[i] && empty[j]) {
                CCPoint pos = center + CCPoint(
                    SIDES[i].dx + SIDES[j].dx,
                    SIDES[i].dy + SIDES[j].dy
                ) * offset;
                if (auto o = editor->createObject(cornerId, pos, false)) {
                    o->setRotation(SIDES[i].rot);
                    placed++;
                }
            }
        }
    }

    Notification::create(
        fmt::format("Auto Edge: placed {} objects", placed),
        NotificationIcon::Success
    )->show();
}

class $modify(AutoEdgeUI, EditorUI) {
    bool init(LevelEditorLayer* layer) {
        if (!EditorUI::init(layer)) return false;

        auto spr = ButtonSprite::create("Edge");
        spr->setScale(0.6f);

        auto btn = CCMenuItemExt::createSpriteExtra(spr, [this](auto) {
            autoEdges(this);
        });

        auto menu = CCMenu::create();
        menu->addChild(btn);
        menu->setPosition({60.f, CCDirector::get()->getWinSize().height - 40.f});
        this->addChild(menu, 100);

        return true;
    }
};
