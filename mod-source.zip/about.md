# Auto Edge

Select blocks, press **Edge**, and decoration objects are placed on every exposed side and outer corner.

Set the object IDs in the mod settings.

Original by yausaf
